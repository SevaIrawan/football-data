/**
 * SCRIPT 1 — FETCH SCHEDULE MUSIM 2025/26
 * =========================================
 * Fungsi: Ambil semua jadwal pertandingan dari football-data.org
 * Liga: Premier League, Serie A, La Liga, Bundesliga, Ligue 1, Champions League
 * Output: Tulis ke Google Sheet kolom schedule (status = SCHEDULED)
 *
 * Cara pakai:
 * 1. npm install axios googleapis dotenv
 * 2. Isi .env dengan API key yang diperlukan
 * 3. node script1_fetch_schedule.js
 */

require("dotenv").config();
const axios = require("axios");
const { google } = require("googleapis");

// ─── CONFIG ────────────────────────────────────────────────────────────────

const FOOTBALL_DATA_API_KEY = process.env.FOOTBALL_DATA_API_KEY; // dari football-data.org
const GOOGLE_SHEET_ID = process.env.GOOGLE_SHEET_ID;
const GOOGLE_SERVICE_ACCOUNT_EMAIL = process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL;
const GOOGLE_PRIVATE_KEY = process.env.GOOGLE_PRIVATE_KEY?.replace(/\\n/g, "\n");
const SHEET_NAME = "Result"; // nama tab di Google Sheet

// Liga yang ingin diambil jadwalnya
// football-data.org competition codes:
// PL  = Premier League (Inggris)
// SA  = Serie A (Italia)
// PD  = La Liga (Spanyol)
// BL1 = Bundesliga (Jerman)
// FL1 = Ligue 1 (Prancis)
// CL  = Champions League
const COMPETITIONS = [
  { code: "PL",  name: "Premier League",   league_logo_key: "premier-league" },
  { code: "SA",  name: "Serie A",          league_logo_key: "serie-a" },
  { code: "PD",  name: "La Liga",          league_logo_key: "la-liga" },
  { code: "BL1", name: "Bundesliga",       league_logo_key: "bundesliga" },
  { code: "FL1", name: "Ligue 1",          league_logo_key: "ligue-1" },
  { code: "CL",  name: "Champions League", league_logo_key: "champions-league" },
];

const SEASON = "2025"; // football-data.org pakai tahun awal musim (2025 = musim 2025/26)

// ─── GOOGLE SHEETS AUTH ────────────────────────────────────────────────────

async function getGoogleSheetsClient() {
  const auth = new google.auth.JWT({
    email: GOOGLE_SERVICE_ACCOUNT_EMAIL,
    key: GOOGLE_PRIVATE_KEY,
    scopes: ["https://www.googleapis.com/auth/spreadsheets"],
  });
  await auth.authorize();
  return google.sheets({ version: "v4", auth });
}

// ─── HELPER: Format tanggal ────────────────────────────────────────────────

function formatDate(utcDateStr) {
  // Input: "2026-04-26T14:00:00Z"
  // Output match_date: "2026-04-26", kickoff: "21:00" (GMT+7)
  const date = new Date(utcDateStr);
  const gmt7 = new Date(date.getTime() + 7 * 60 * 60 * 1000);

  const match_date = gmt7.toISOString().split("T")[0]; // YYYY-MM-DD

  const hh = String(gmt7.getUTCHours()).padStart(2, "0");
  const mm = String(gmt7.getUTCMinutes()).padStart(2, "0");
  const kickoff = `${hh}:${mm}`; // HH:mm

  return { match_date, kickoff };
}

function formatSeason(year) {
  // 2025 → "2025/26"
  return `${year}/${String(Number(year) + 1).slice(-2)}`;
}

// ─── FETCH JADWAL DARI FOOTBALL-DATA.ORG ──────────────────────────────────

async function fetchSchedule(competitionCode) {
  try {
    console.log(`\n📡 Fetching ${competitionCode}...`);

    const response = await axios.get(
      `https://api.football-data.org/v4/competitions/${competitionCode}/matches`,
      {
        headers: { "X-Auth-Token": FOOTBALL_DATA_API_KEY },
        params: { season: SEASON },
      }
    );

    const matches = response.data.matches;
    console.log(`   ✓ ${matches.length} matches ditemukan`);
    return matches;
  } catch (error) {
    if (error.response?.status === 429) {
      console.log(`   ⚠ Rate limit hit, tunggu 60 detik...`);
      await new Promise((r) => setTimeout(r, 60000));
      return fetchSchedule(competitionCode); // retry
    }
    console.error(`   ✗ Error: ${error.response?.data?.message || error.message}`);
    return [];
  }
}

// ─── TRANSFORM DATA KE FORMAT SHEET ───────────────────────────────────────

function transformMatch(match, competition) {
  const { match_date, kickoff } = formatDate(match.utcDate);
  const season = formatSeason(SEASON);

  // Inisial nama tim untuk logo key (lowercase, dash)
  const homeKey = match.homeTeam.shortName
    ?.toLowerCase().replace(/\s+/g, "-") || "";
  const awayKey = match.awayTeam.shortName
    ?.toLowerCase().replace(/\s+/g, "-") || "";

  // Logo dari football-data.org (crest URL)
  const homeLogo = match.homeTeam.crest || "";
  const awayLogo = match.awayTeam.crest || "";
  const leagueLogo = match.competition?.emblem || "";

  // Matchweek
  const matchweek = match.matchday || "";

  // Row sesuai urutan 35 kolom di Google Sheet
  return [
    competition.name,          // 1. league_name
    season,                    // 2. season
    matchweek,                 // 3. matchweek
    match_date,                // 4. match_date
    kickoff,                   // 5. kickoff
    leagueLogo,                // 6. league_logo_url
    competition.league_logo_key, // 7. league_logo_key
    match.homeTeam.name || "", // 8. home_name
    match.awayTeam.name || "", // 9. away_name
    homeLogo,                  // 10. home_logo_url
    awayLogo,                  // 11. away_logo_url
    homeKey,                   // 12. home_logo_key
    awayKey,                   // 13. away_logo_key
    "SCHEDULED",               // 14. status
    "",                        // 15. home_score
    "",                        // 16. away_score
    "",                        // 17. shots_on_target_home
    "",                        // 18. shots_on_target_away
    "",                        // 19. possession_home
    "",                        // 20. possession_away
    "",                        // 21. corners_home
    "",                        // 22. corners_away
    "",                        // 23. fouls_home
    "",                        // 24. fouls_away
    "",                        // 25. yellow_cards_home
    "",                        // 26. yellow_cards_away
    "",                        // 27. red_cards_home
    "",                        // 28. red_cards_away
    "",                        // 29. home_goal_scorers
    "",                        // 30. away_goal_scorers
    "",                        // 31. flashscore_url
    "PENDING",                 // 32. generate_video
    "",                        // 33. uploaded_at
    "",                        // 34. home_league_rank
    "",                        // 35. away_league_rank
  ];
}

// ─── CEK DUPLIKAT DI SHEET ─────────────────────────────────────────────────

async function getExistingMatches(sheets) {
  // Ambil kolom home_name (col H = index 7) + match_date (col D = index 3)
  const res = await sheets.spreadsheets.values.get({
    spreadsheetId: GOOGLE_SHEET_ID,
    range: `${SHEET_NAME}!A2:I`,
  });

  const rows = res.data.values || [];
  const existing = new Set();

  for (const row of rows) {
    const league = row[0] || "";
    const matchDate = row[3] || "";
    const homeName = row[7] || "";
    const awayName = row[8] || "";
    const key = `${league}|${matchDate}|${homeName}|${awayName}`;
    existing.add(key);
  }

  return existing;
}

// ─── TULIS KE GOOGLE SHEET ─────────────────────────────────────────────────

async function writeToSheet(sheets, rows) {
  if (rows.length === 0) {
    console.log("   Tidak ada data baru untuk ditulis.");
    return;
  }

  await sheets.spreadsheets.values.append({
    spreadsheetId: GOOGLE_SHEET_ID,
    range: `${SHEET_NAME}!A1`,
    valueInputOption: "USER_ENTERED",
    insertDataOption: "INSERT_ROWS",
    requestBody: { values: rows },
  });

  console.log(`   ✓ ${rows.length} baris berhasil ditulis ke Sheet`);
}

// ─── MAIN ──────────────────────────────────────────────────────────────────

async function main() {
  console.log("🚀 Script 1 — Fetch Schedule Musim 2025/26");
  console.log("===========================================");

  // Validasi env
  if (!FOOTBALL_DATA_API_KEY) {
    console.error("❌ FOOTBALL_DATA_API_KEY belum diisi di .env");
    process.exit(1);
  }
  if (!GOOGLE_SHEET_ID || !GOOGLE_SERVICE_ACCOUNT_EMAIL || !GOOGLE_PRIVATE_KEY) {
    console.error("❌ Google Sheets credentials belum lengkap di .env");
    process.exit(1);
  }

  // Connect ke Google Sheets
  console.log("\n🔗 Connecting ke Google Sheets...");
  const sheets = await getGoogleSheetsClient();
  console.log("   ✓ Connected");

  // Ambil data yang sudah ada untuk cek duplikat
  console.log("\n📋 Mengambil data existing dari Sheet...");
  const existing = await getExistingMatches(sheets);
  console.log(`   ✓ ${existing.size} match sudah ada di Sheet`);

  let totalNew = 0;

  // Loop tiap liga
  for (const competition of COMPETITIONS) {
    const matches = await fetchSchedule(competition.code);

    const newRows = [];
    for (const match of matches) {
      const row = transformMatch(match, competition);

      // Cek duplikat
      const key = `${row[0]}|${row[3]}|${row[7]}|${row[8]}`;
      if (existing.has(key)) continue;

      newRows.push(row);
      existing.add(key); // tambah ke set supaya tidak duplikat dalam batch yang sama
    }

    if (newRows.length > 0) {
      console.log(`\n✍️  Menulis ${newRows.length} match baru untuk ${competition.name}...`);
      await writeToSheet(sheets, newRows);
      totalNew += newRows.length;
    } else {
      console.log(`\n⏭  ${competition.name}: semua match sudah ada di Sheet`);
    }

    // Delay 6 detik antar liga — football-data.org limit 10 req/menit
    if (COMPETITIONS.indexOf(competition) < COMPETITIONS.length - 1) {
      console.log("   ⏳ Tunggu 6 detik (rate limit)...");
      await new Promise((r) => setTimeout(r, 6000));
    }
  }

  console.log("\n===========================================");
  console.log(`✅ Selesai! Total ${totalNew} match baru ditambahkan ke Sheet`);
  console.log("===========================================\n");
}

main().catch((err) => {
  console.error("❌ Fatal error:", err.message);
  process.exit(1);
});

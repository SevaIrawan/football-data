/**
 * SCRIPT 2 — UPDATE SCORE, STATISTIK, RANK & GOAL SCORERS
 * =========================================================
 * Fungsi: Cek match yang sudah FINISHED → update skor, statistik,
 *         goal scorers, dan league rank ke Google Sheet
 *
 * Source data:
 * - football-data.org → skor final, goal scorers, league rank
 * - FlashScore (Puppeteer) → statistik detail (shots, possession, dll)
 *
 * Cara pakai:
 * 1. npm install axios googleapis dotenv puppeteer-extra puppeteer-extra-plugin-stealth
 * 2. Isi .env dengan API key yang diperlukan
 * 3. node script2_update_results.js
 *
 * Jalankan sebagai cron job tiap 10 menit:
 * Contoh crontab: */10 * * * * node /path/to/script2_update_results.js
 */

require("dotenv").config();
const axios = require("axios");
const { google } = require("googleapis");
const puppeteer = require("puppeteer-extra");
const StealthPlugin = require("puppeteer-extra-plugin-stealth");

puppeteer.use(StealthPlugin());

// ─── CONFIG ────────────────────────────────────────────────────────────────

const FOOTBALL_DATA_API_KEY = process.env.FOOTBALL_DATA_API_KEY;
const GOOGLE_SHEET_ID = process.env.GOOGLE_SHEET_ID;
const GOOGLE_SERVICE_ACCOUNT_EMAIL = process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL;
const GOOGLE_PRIVATE_KEY = process.env.GOOGLE_PRIVATE_KEY?.replace(/\\n/g, "\n");
const SHEET_NAME = "Result";

const COMPETITIONS = [
  { code: "PL",  name: "Premier League" },
  { code: "SA",  name: "Serie A" },
  { code: "PD",  name: "La Liga" },
  { code: "BL1", name: "Bundesliga" },
  { code: "FL1", name: "Ligue 1" },
  { code: "CL",  name: "Champions League" },
];

// Kolom index di Sheet (0-based, kolom A = 0)
const COL = {
  league_name:           0,  // A
  season:                1,  // B
  matchweek:             2,  // C
  match_date:            3,  // D
  kickoff:               4,  // E
  league_logo_url:       5,  // F
  league_logo_key:       6,  // G
  home_name:             7,  // H
  away_name:             8,  // I
  home_logo_url:         9,  // J
  away_logo_url:         10, // K
  home_logo_key:         11, // L
  away_logo_key:         12, // M
  status:                13, // N
  home_score:            14, // O
  away_score:            15, // P
  shots_on_target_home:  16, // Q
  shots_on_target_away:  17, // R
  possession_home:       18, // S
  possession_away:       19, // T
  corners_home:          20, // U
  corners_away:          21, // V
  fouls_home:            22, // W
  fouls_away:            23, // X
  yellow_cards_home:     24, // Y
  yellow_cards_away:     25, // Z
  red_cards_home:        26, // AA
  red_cards_away:        27, // AB
  home_goal_scorers:     28, // AC
  away_goal_scorers:     29, // AD
  flashscore_url:        30, // AE
  generate_video:        31, // AF
  uploaded_at:           32, // AG
  home_league_rank:      33, // AH
  away_league_rank:      34, // AI
};

// ─── GOOGLE SHEETS AUTH ────────────────────────────────────────────────────

async function getGoogleSheetsClient() {
  const auth = new google.auth.JWT({
    email: GOOGLE_SERVICE_ACCOUNT_EMAIL,
    key: GOOGLE_PRIVATE_KEY,
    scopes: ["https://www.googleapis.com/auth/spreadsheets"],
  });
  await auth.authorize();
  return google.sheets({ version: "v4", auth });
}

// ─── AMBIL SEMUA BARIS DARI SHEET ─────────────────────────────────────────

async function getAllRows(sheets) {
  const res = await sheets.spreadsheets.values.get({
    spreadsheetId: GOOGLE_SHEET_ID,
    range: `${SHEET_NAME}!A2:AI`,
  });
  return res.data.values || [];
}

// ─── FETCH HASIL MATCH DARI FOOTBALL-DATA.ORG ─────────────────────────────

async function fetchFinishedMatches(competitionCode) {
  try {
    const response = await axios.get(
      `https://api.football-data.org/v4/competitions/${competitionCode}/matches`,
      {
        headers: { "X-Auth-Token": FOOTBALL_DATA_API_KEY },
        params: { season: "2025", status: "FINISHED" },
      }
    );
    return response.data.matches || [];
  } catch (error) {
    if (error.response?.status === 429) {
      console.log("   ⚠ Rate limit, tunggu 60 detik...");
      await new Promise((r) => setTimeout(r, 60000));
      return fetchFinishedMatches(competitionCode);
    }
    console.error(`   ✗ Error fetch ${competitionCode}:`, error.message);
    return [];
  }
}

// ─── FETCH KLASEMEN DARI FOOTBALL-DATA.ORG ────────────────────────────────

async function fetchStandings(competitionCode) {
  try {
    const response = await axios.get(
      `https://api.football-data.org/v4/competitions/${competitionCode}/standings`,
      {
        headers: { "X-Auth-Token": FOOTBALL_DATA_API_KEY },
        params: { season: "2025" },
      }
    );

    // Ambil total standings (bukan home/away)
    const table = response.data.standings?.find(
      (s) => s.type === "TOTAL"
    )?.table || [];

    // Buat map: nama tim → posisi
    const rankMap = {};
    for (const entry of table) {
      rankMap[entry.team.name] = entry.position;
      // Tambah shortName juga sebagai alias
      if (entry.team.shortName) {
        rankMap[entry.team.shortName] = entry.position;
      }
    }

    return rankMap;
  } catch (error) {
    console.error(`   ✗ Error fetch standings ${competitionCode}:`, error.message);
    return {};
  }
}

// ─── FORMAT GOAL SCORERS ───────────────────────────────────────────────────

function formatGoalScorers(scorers, teamName) {
  if (!scorers || scorers.length === 0) return "";

  return scorers
    .filter((s) => s.team?.name === teamName || s.team?.shortName === teamName)
    .map((s) => {
      const name = s.scorer?.name || s.scorer?.shortName || "Unknown";
      const minute = s.minute ? `${s.minute}'` : "";
      const addedTime = s.injuryTime ? `+${s.injuryTime}'` : "";
      return `${name} ${minute}${addedTime}`.trim();
    })
    .join(", ");
}

// ─── SCRAPING STATISTIK DARI FLASHSCORE ───────────────────────────────────

async function scrapeFlashScoreStats(flashscoreUrl, browser) {
  if (!flashscoreUrl) return null;

  const page = await browser.newPage();

  try {
    console.log(`   🔍 Scraping FlashScore: ${flashscoreUrl}`);

    // Set user agent supaya tidak kena block
    await page.setUserAgent(
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
      "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    );

    await page.setViewport({ width: 1280, height: 800 });

    // Navigate ke halaman match
    await page.goto(flashscoreUrl, {
      waitUntil: "networkidle2",
      timeout: 30000,
    });

    // Tunggu konten load
    await new Promise((r) => setTimeout(r, 3000));

    // Klik tab Statistics jika ada
    try {
      const statsTab = await page.$('[data-tabid="statistics"]');
      if (statsTab) {
        await statsTab.click();
        await new Promise((r) => setTimeout(r, 2000));
      }
    } catch (_) {}

    // Extract statistik
    const stats = await page.evaluate(() => {
      const result = {
        shots_on_target_home: "",
        shots_on_target_away: "",
        possession_home: "",
        possession_away: "",
        corners_home: "",
        corners_away: "",
        fouls_home: "",
        fouls_away: "",
        yellow_cards_home: "",
        yellow_cards_away: "",
        red_cards_home: "",
        red_cards_away: "",
      };

      // FlashScore stat rows — label di tengah, nilai home di kiri, away di kanan
      const rows = document.querySelectorAll(
        "[class*='stat__row'], [class*='statRow'], .statRow"
      );

      for (const row of rows) {
        const label = row.querySelector(
          "[class*='stat__categoryName'], [class*='statCategory']"
        )?.textContent?.trim().toLowerCase() || "";

        const homeVal = row.querySelector(
          "[class*='stat__homeValue'], [class*='homeValue']"
        )?.textContent?.trim().replace("%", "") || "";

        const awayVal = row.querySelector(
          "[class*='stat__awayValue'], [class*='awayValue']"
        )?.textContent?.trim().replace("%", "") || "";

        if (label.includes("shots on target") || label.includes("shots on goal")) {
          result.shots_on_target_home = homeVal;
          result.shots_on_target_away = awayVal;
        } else if (label.includes("ball possession") || label.includes("possession")) {
          result.possession_home = homeVal;
          result.possession_away = awayVal;
        } else if (label.includes("corner kicks") || label.includes("corners")) {
          result.corners_home = homeVal;
          result.corners_away = awayVal;
        } else if (label.includes("fouls") || label.includes("free kicks")) {
          result.fouls_home = homeVal;
          result.fouls_away = awayVal;
        } else if (label.includes("yellow cards")) {
          result.yellow_cards_home = homeVal;
          result.yellow_cards_away = awayVal;
        } else if (label.includes("red cards")) {
          result.red_cards_home = homeVal;
          result.red_cards_away = awayVal;
        }
      }

      return result;
    });

    console.log(`   ✓ Statistik berhasil di-scraping`);
    return stats;

  } catch (error) {
    console.error(`   ✗ Error scraping: ${error.message}`);
    return null;
  } finally {
    await page.close();
    // Delay antar request supaya tidak kena block
    await new Promise((r) => setTimeout(r, 4000));
  }
}

// ─── UPDATE BARIS DI SHEET ─────────────────────────────────────────────────

async function updateSheetRow(sheets, rowIndex, updatedValues) {
  // rowIndex = index dari array rows (0-based), +2 karena header di row 1
  const sheetRow = rowIndex + 2;

  await sheets.spreadsheets.values.update({
    spreadsheetId: GOOGLE_SHEET_ID,
    range: `${SHEET_NAME}!A${sheetRow}:AI${sheetRow}`,
    valueInputOption: "USER_ENTERED",
    requestBody: { values: [updatedValues] },
  });
}

// ─── AUTO GROUP 6 MATCH → SET generate_video = YES ────────────────────────

async function autoGroupVideoQueue(sheets, allRows) {
  // Cari rows yang FINISHED tapi generate_video masih PENDING
  const pendingRows = [];

  for (let i = 0; i < allRows.length; i++) {
    const row = allRows[i];
    const status = row[COL.status] || "";
    const generateVideo = row[COL.generate_video] || "";

    if (status === "FINISHED" && generateVideo === "PENDING") {
      pendingRows.push({ index: i, row });
    }
  }

  // Cek apakah ada YES yang sedang dalam proses
  const hasActiveYes = allRows.some(
    (row) => (row[COL.generate_video] || "") === "YES"
  );

  // Kalau tidak ada yang sedang YES, ambil 6 pertama dan set YES
  if (!hasActiveYes && pendingRows.length > 0) {
    const batch = pendingRows.slice(0, 6);
    console.log(`\n🎬 Auto-set ${batch.length} match ke generate_video = YES`);

    for (const item of batch) {
      const updatedRow = [...item.row];
      // Pastikan array cukup panjang (35 kolom)
      while (updatedRow.length < 35) updatedRow.push("");
      updatedRow[COL.generate_video] = "YES";

      await updateSheetRow(sheets, item.index, updatedRow);
      console.log(
        `   ✓ ${item.row[COL.home_name]} vs ${item.row[COL.away_name]} → YES`
      );
    }
  } else if (hasActiveYes) {
    console.log("\n⏳ Masih ada batch YES yang belum selesai, skip auto-group");
  } else {
    console.log("\n✅ Tidak ada match PENDING baru");
  }
}

// ─── MAIN ──────────────────────────────────────────────────────────────────

async function main() {
  console.log("🚀 Script 2 — Update Score, Statistik, Rank & Goal Scorers");
  console.log("============================================================");

  // Validasi env
  if (!FOOTBALL_DATA_API_KEY || !GOOGLE_SHEET_ID || !GOOGLE_SERVICE_ACCOUNT_EMAIL) {
    console.error("❌ Environment variables belum lengkap di .env");
    process.exit(1);
  }

  // Connect Google Sheets
  console.log("\n🔗 Connecting ke Google Sheets...");
  const sheets = await getGoogleSheetsClient();
  const allRows = await getAllRows(sheets);
  console.log(`   ✓ ${allRows.length} baris ditemukan di Sheet`);

  // Launch Puppeteer untuk FlashScore
  console.log("\n🌐 Launch Puppeteer browser...");
  const browser = await puppeteer.launch({
    headless: "new",
    args: ["--no-sandbox", "--disable-setuid-sandbox"],
  });

  let totalUpdated = 0;

  // Loop tiap liga
  for (const competition of COMPETITIONS) {
    console.log(`\n📡 Processing ${competition.name}...`);

    // Fetch hasil FINISHED dari football-data.org
    const finishedMatches = await fetchFinishedMatches(competition.code);
    console.log(`   ✓ ${finishedMatches.length} match FINISHED ditemukan`);

    if (finishedMatches.length === 0) continue;

    // Fetch klasemen
    console.log(`   📊 Fetching klasemen ${competition.name}...`);
    const rankings = await fetchStandings(competition.code);

    // Loop tiap match FINISHED
    for (const match of finishedMatches) {
      // Cari baris di Sheet yang cocok
      const rowIndex = allRows.findIndex((row) => {
        const rowHomeName = (row[COL.home_name] || "").toLowerCase().trim();
        const rowAwayName = (row[COL.away_name] || "").toLowerCase().trim();
        const rowMatchDate = (row[COL.match_date] || "").trim();
        const rowStatus = (row[COL.status] || "").trim();

        const matchHomeName = (match.homeTeam.name || "").toLowerCase().trim();
        const matchAwayName = (match.awayTeam.name || "").toLowerCase().trim();
        const matchDate = match.utcDate?.split("T")[0] || "";

        return (
          rowStatus !== "FINISHED" && // skip yang sudah diupdate
          rowMatchDate === matchDate &&
          rowHomeName === matchHomeName &&
          rowAwayName === matchAwayName
        );
      });

      if (rowIndex === -1) continue; // tidak ada di sheet

      const row = [...allRows[rowIndex]];
      while (row.length < 35) row.push("");

      // Update skor
      const homeScore = match.score?.fullTime?.home ?? "";
      const awayScore = match.score?.fullTime?.away ?? "";
      row[COL.home_score] = homeScore;
      row[COL.away_score] = awayScore;
      row[COL.status] = "FINISHED";

      // Update goal scorers dari football-data.org
      const scorers = match.goals || [];
      row[COL.home_goal_scorers] = formatGoalScorers(scorers, match.homeTeam.name);
      row[COL.away_goal_scorers] = formatGoalScorers(scorers, match.awayTeam.name);

      // Update league rank dari klasemen
      row[COL.home_league_rank] = rankings[match.homeTeam.name] || rankings[match.homeTeam.shortName] || "";
      row[COL.away_league_rank] = rankings[match.awayTeam.name] || rankings[match.awayTeam.shortName] || "";

      // Scraping statistik dari FlashScore jika ada URL
      const flashscoreUrl = row[COL.flashscore_url] || "";
      if (flashscoreUrl) {
        const stats = await scrapeFlashScoreStats(flashscoreUrl, browser);
        if (stats) {
          row[COL.shots_on_target_home] = stats.shots_on_target_home;
          row[COL.shots_on_target_away] = stats.shots_on_target_away;
          row[COL.possession_home] = stats.possession_home;
          row[COL.possession_away] = stats.possession_away;
          row[COL.corners_home] = stats.corners_home;
          row[COL.corners_away] = stats.corners_away;
          row[COL.fouls_home] = stats.fouls_home;
          row[COL.fouls_away] = stats.fouls_away;
          row[COL.yellow_cards_home] = stats.yellow_cards_home;
          row[COL.yellow_cards_away] = stats.yellow_cards_away;
          row[COL.red_cards_home] = stats.red_cards_home;
          row[COL.red_cards_away] = stats.red_cards_away;
        }
      } else {
        console.log(`   ⚠ flashscore_url kosong untuk ${match.homeTeam.name} vs ${match.awayTeam.name}, skip statistik`);
      }

      // Tulis update ke Sheet
      await updateSheetRow(sheets, rowIndex, row);

      // Update local cache
      allRows[rowIndex] = row;
      totalUpdated++;

      console.log(
        `   ✓ Updated: ${match.homeTeam.name} ${homeScore}-${awayScore} ${match.awayTeam.name}`
      );
    }

    // Delay antar liga
    console.log("   ⏳ Delay 6 detik (rate limit)...");
    await new Promise((r) => setTimeout(r, 6000));
  }

  // Tutup browser
  await browser.close();

  // Auto-group 6 match → set generate_video = YES
  await autoGroupVideoQueue(sheets, allRows);

  console.log("\n============================================================");
  console.log(`✅ Selesai! Total ${totalUpdated} match diupdate`);
  console.log("============================================================\n");
}

main().catch((err) => {
  console.error("❌ Fatal error:", err.message);
  process.exit(1);
});
